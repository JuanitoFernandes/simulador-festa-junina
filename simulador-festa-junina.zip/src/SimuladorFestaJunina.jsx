import { useState } from "react";
import { Card, CardContent } from "./components/ui/card";
import { Input } from "./components/ui/input";

const dados = Array.from({ length: 71 }, (_, i) => {
  const qtd = i + 30;
  const precoBuffet = qtd <= 50 ? 40 : qtd <= 80 ? 35 : 30;
  const custoBuffet = qtd * precoBuffet;
  const custoTotal = custoBuffet + 1500;
  const receitaTotal =
    qtd <= 30 ? qtd * 100 : 30 * 100 + (qtd - 30) * 120;
  const lucro = receitaTotal - custoTotal;
  return {
    ingressos: qtd,
    receita: receitaTotal,
    custo: custoTotal,
    lucro: lucro,
    lucroPorIngresso: lucro / qtd,
    lucroPorOrganizador: lucro / 3,
    precoBuffet,
  };
});

export default function SimuladorFestaJunina() {
  const [qtdIngressos, setQtdIngressos] = useState(30);
  const resultado = dados.find((d) => d.ingressos === Number(qtdIngressos));

  return (
    <div className="max-w-xl mx-auto p-4 space-y-4">
      <h1 className="text-2xl font-bold">Simulador de Lucro - Festa Junina</h1>
      <Input
        type="number"
        min="30"
        max="100"
        value={qtdIngressos}
        onChange={(e) => setQtdIngressos(e.target.value)}
        placeholder="Digite o número de ingressos (30 a 100)"
      />
      {resultado ? (
        <Card>
          <CardContent className="p-4 space-y-2 text-base">
            <p><strong>Ingressos vendidos:</strong> {resultado.ingressos}</p>
            <p><strong>Receita total:</strong> R$ {resultado.receita.toFixed(2)}</p>
            <p><strong>Custo total:</strong> R$ {resultado.custo.toFixed(2)}</p>
            <p><strong>Lucro líquido:</strong> R$ {resultado.lucro.toFixed(2)}</p>
            <p><strong>Lucro por ingresso:</strong> R$ {resultado.lucroPorIngresso.toFixed(2)}</p>
            <p><strong>Lucro por organizador:</strong> R$ {resultado.lucroPorOrganizador.toFixed(2)}</p>
            <p><strong>Preço do buffet por pessoa:</strong> R$ {resultado.precoBuffet}</p>
          </CardContent>
        </Card>
      ) : (
        <p className="text-red-600">Digite um número entre 30 e 100.</p>
      )}
    </div>
  );
}
