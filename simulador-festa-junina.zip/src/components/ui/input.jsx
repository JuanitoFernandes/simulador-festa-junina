export function Input(props) {
  return <input {...props} />
}
